#
# Cookbook Name:: simple-test-app
# Library:: java_webapp_lib
#
# Copyright 2015 Cloudstead, Inc.
#

class Chef::Recipe::Simple_test_app

    def self.init (chef, app)
        chef.package 'openjdk-7-jre-headless' do
            action :install
        end
    end

end