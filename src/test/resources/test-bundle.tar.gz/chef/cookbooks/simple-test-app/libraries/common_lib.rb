#
# Cookbook Name:: simple-test-app
# Library:: common_lib
#
# Copyright 2015 Cloudstead, Inc.
#

require 'time'
require 'digest/sha1'

class Chef::Recipe::Simple_test_app

    def self.define_app (chef)
        base = Chef::Recipe::Base
        app = {
            :lib => self,
            :name => 'simple-test-app',
            :path => 'bogus',
            :hostname => %x(hostname).strip,
            :ipaddress => chef.node['ipaddress'],
            :uniq => [],
            :rand => [],
            :services => [],
            :service_names => {},
            :chef_user => base.chef_user,
            :chef_user_home => base.chef_user_home,
            :mail_user => 'cloudos_system_mailer',
            :mail_password => base.password('system_mailer'),
            :cloudos_port => base.primary_port(chef, 'cloudos')
        }

        # default service name
        app[:default_service_name] = app[:name].gsub('-', '_').gsub(/\W/, '')

        (0...9).each do |n|
        app[:uniq] << base.password("simple-test-app_#{n}")
        app[:rand] << SecureRandom.hex(64)
        end






    


        app[:databag] = {}
        app[:databag_replacements] = {}

        # If we have a ports databag, define it and populate replacements
        begin
            app[:databag][:ports] = base.ports_databag chef, 'simple-test-app'
            app[:databag][:ports].each do |bagkey, bagvalue|
                define_databag_replacements app, app[:databag_replacements], "@config[ports]", bagkey, bagvalue
            end
        rescue => e
            puts "simple-test-app/ports databag not found or error reading: #{e}"
        end

        # If we have a base databag, define it and populate replacements, then set hostname
        begin
            app[:databag][:base] = chef.data_bag_item('simple-test-app', 'base')
            app[:databag][:base].each do |bagkey, bagvalue|
                define_databag_replacements app, app[:databag_replacements], "@config[base]", bagkey, bagvalue
            end

            # set the hostname based on values in the base databag
            hostname = app[:databag][:base]['hostname']
            app[:domain] = parent_domain = app[:databag][:base]['parent_domain']
            fqdn = "#{hostname}.#{parent_domain}"

            # But only if we are already this hostname -- the install.sh script should set the hostname for us
            raise "Please run with install.sh: system hostname (#{app[:hostname]}) didn't match base databag value (#{fqdn})" unless app[:hostname] == fqdn

            base.set_hostname self, fqdn

        rescue => e
            puts "simple-test-app/base databag not found or error reading: #{e}"
        end

        # If there is a cloudos-init databag, define it as @cloudos
        begin
            app[:cloudos_databag] = chef.data_bag_item('cloudos', 'init')
            app[:cloudos_databag].each do |bagkey, bagvalue|
                define_databag_replacements app, app[:databag_replacements], "@cloudos", bagkey, bagvalue
            end
        rescue => e
            puts "cloudos/init databag not found or error reading: #{e}"
        end

        app[:domain] ||= %x(hostname -d).strip

        
            
                
        # Before defining databag replacements, check for any empty passwords that should be auto-generated
        config_category = 'init'
        databag = nil
        begin
            databag = chef.data_bag_item('simple-test-app', config_category)
        rescue => e
            puts "Error loading databag: simple-test-app/#{config_category}"
        end

        if databag
                    
                        
                    
                        
            if databag['admin']['password'].to_s.empty?
                databag_file = "#{base.chef_databags(app[:name])}/#{config_category}.json"
                raise "Missing databag: #{databag_file}" unless File.exists? databag_file

                            
                # password field knows where its login field is
                raise 'Error determining login for auto-generated password: admin.password' if 'admin.name'.to_s.empty?

                if 'admin.name'.start_with? '#'
                    login = 'admin.name'[1..-1]
                else
                    login = databag['admin']['name'] unless 'admin.name'.to_s.empty?
                end
                            
                raise 'Error determining login for auto-generated password: admin.password' if login.to_s.empty?

                # Write generated password to databag, update databag struct, email password to admin
                generate_password_and_notify chef, app, login, 'admin.password', databag_file
            end
                        
                    
                        
                    
        end
                
            
        

        
            
        app[:databag][:init] = chef.data_bag_item('simple-test-app', 'init')
        app[:databag][:init].each do |bagkey, bagvalue|
            define_databag_replacements app, app[:databag_replacements], '@config[init]', bagkey, bagvalue
        end
            
        

        
        app[:web] = {}
        app[:web][:mode] = 'proxy_service'
          
        app[:mount] = subst_string('bogus', app)
          

          
        app[:local_mount] = subst_string('', app)
          
        

        app[:ldap_domain] = "dc=#{app[:domain].gsub(/\./, ',dc=')}"

        # note: init is defined in libraries/java_webapp_lib.rb
        init chef, app
        init_user chef, app
        set_database_config app if defined? set_database_config

        app[:groups] = {}
        

        
        

        
        app[:service_url] = apache_service_url(app)
        

        return app
    end

    DATABAG_SIMPLE_TYPES = [ String, Fixnum, TrueClass, FalseClass ]
    def self.define_databag_replacements(app, hash, base, bagkey, bagvalue)
        if DATABAG_SIMPLE_TYPES.include?(bagvalue.class)
            hash["#{base}[#{bagkey}]"] = subst_string(bagvalue.to_s, app)
        elsif bagvalue
            bagvalue.each do |subkey, subvalue|
              define_databag_replacements app, hash, "#{base}[#{bagkey}]", subkey, subvalue
            end
        end
    end

    def self.subst_path (value, app)
        subst(value, app, true)
    end

    def self.subst_string (value, app)
        subst(value, app, false)
    end

    def self.subst (value, app, is_path = true)
        return nil if value.to_s.empty?

        base = Chef::Recipe::Base

        if app
            # Perform databag replacements first, since they may contain other @directives
            if app[:databag_replacements]
                app[:databag_replacements].each do |find, replace|
                    value = value.gsub(find, replace.to_s)
                end
            end


            doc_root = (defined?(app[:doc_root]) && app[:doc_root]) ? app[:doc_root] : '@doc_root_undefined'
            run_as = (defined?(app[:run_as]) && app[:run_as]) ? app[:run_as] : '@run_as_undefined'
            run_as_home = (defined?(app[:run_as_home]) && app[:run_as_home]) ? app[:run_as_home] : '@run_as_home_undefined'

            value = value.gsub('@doc_root', doc_root)
            value = value.gsub('@name', app[:name])
            value = value.gsub('@ipaddress', app[:ipaddress])
            value = value.gsub('@hostname', %x(hostname).strip)
            value = value.gsub('@domain', app[:domain]) if app[:domain]
            value = value.gsub('@run_as', run_as)
            value = value.gsub('@home', run_as_home)
            value = value.gsub('@mail_user', app[:mail_user])
            value = value.gsub('@mail_password', app[:mail_password])
            value = value.gsub('@dbname', app[:dbname]) if app[:dbname]
            value = value.gsub('@dbuser', app[:dbuser]) if app[:dbuser]
            value = value.gsub('@dbpass', app[:dbpass]) if app[:dbpass]

            value = value.gsub('@backup_dir', app[:backup_dir]) if app[:backup_dir]
            value = value.gsub('@backup_timestamp', app[:backup_timestamp]) if app[:backup_timestamp]

            (0...9).each do |n|
                value = value.gsub("@uniq[#{n}]", app[:uniq][n])
                value = value.gsub("@rand[#{n}]", app[:rand][n])
            end





        end

        value = value.gsub('@chef_user', base.chef_user)
        value = value.gsub('@chef_home', base.chef_user_home)
        value = value.gsub('@files', "#{base.chef_files(app[:name])}")
        value = value.gsub('@templates', "#{base.chef_templates(app[:name])}")
        value = value.gsub('@now_millis', (1000*Time.now.to_f).to_i.to_s)
        value = value.gsub('@timezone', %x(cat /etc/timezone).strip) if File.exists? '/etc/timezone'
        value = value.gsub('@web_mode', 'proxy_service') unless 'proxy_service'.empty?
        value = value.gsub('@lang', %x(locale | grep LANG= | tr '=_' ' ' | awk '{print $2}').strip) if value.include?('@lang')
        value = value.gsub('@locale', %x(locale | grep LANG= | tr '=.' ' ' | awk '{print $2}').strip) if value.include?('@locale')

        if value.include? '@currency_code'
          money_locale = %x(locale | grep LC_MONETARY | tr '=".' ' ' | awk '{print $2}').strip
          if money_locale.length > 0
            money_locale = 'en_US' if money_locale == 'POSIX'
            locale_file="/usr/share/i18n/locales/#{money_locale}"
            if File.exists? locale_file
              currency_code = %x(cat #{locale_file} | grep int_curr_symbol | awk '{print $2}' | tr -d '"' | sed -e 's,<U, ,g' | tr -d '>').strip.split(" ").map(&:hex).pack('C*').force_encoding('utf-8').strip
              if currency_code.empty?
                raise "Error determining currency code from #{locale_file}"
              end
              value = value.gsub('@currency_code', currency_code)
            end
          end
        end

        if defined? Chef::Recipe::Java.java_home
            java_home = Chef::Recipe::Java.java_home
            value = value.gsub('@java_home', java_home) unless java_home.nil?
        end

        if app && !value.start_with?('/') && is_path
            value = "#{app[:run_as_home]}/#{value}"
        end

        # Look for function prefixes and process their innards
        { '@lower'  => lambda { |val| val.downcase },
          '@length' => lambda { |val| val.length },
          '@now'    => lambda { |val| val == 'mysql' ? Time.now.strftime('%Y-%m-%d %H:%M:%S') : Time.now.strftime(val) },
          '@sha1'   => lambda { |val| Digest::SHA1.hexdigest(val) },
          '@sha256' => lambda { |val| Digest::SHA256.hexdigest(val) },
          '@md5'    => lambda { |val| Digest::MD5.hexdigest(val) },
          '@bcrypt' => lambda { |val|
                if val =~ /,[\s]*[\d]+$/
                    matches = /^(.+),[\s]*([\d]+)$/.match(val)
                    password = matches[1]
                    rounds = matches[2]
                    Chef::Recipe::Base.bcrypt(password, rounds)
                else
                    Chef::Recipe::Base.bcrypt(val)
                end
          },
          '@exec'   => lambda { |val| %x(#{val}).strip } }.each do |fname, func|
            prefix = "#{fname}("
            found = value.index prefix
            while found
                closing_paren = value.index ')', found+1
                inner_value = value[found + prefix.length, closing_paren - found - prefix.length]
                value = value.sub("#{prefix}#{inner_value})", func.call(inner_value))
                found = value.index prefix
            end
        end

        value
    end

    def self.install_package (chef, pkg)
        if pkg.start_with? 'pecl/'
            pecl_package = pkg['pecl/'.length..-1]
            chef.bash "install pecl package #{pecl_package}" do
                user 'root'
code <<-EOH
pecl install #{pecl_package}
EOH
                only_if { %x(pecl list | grep "^#{pecl_package} " | wc -l | tr -d ' ').strip.empty? }
            end
        else
            chef.package pkg do
                action :install
            end
        end
    end

    def self.define_group(chef, app, group_name, members_list = nil)
        if members_list
            chef.group group_name do
                action :create
                members "#{members_list.join(',')}"
            end
        else
            chef.group group_name do
                action :create
            end
        end
    end

    def self.group_exists? group_name
        %x(grep '^#{group_name}:' | wc -l).strip
    end

    def self.user(chef, app, user_name, user_home, group_name, can_login, is_system)
        if user_home
            chef.directory user_home do
                owner user_name
                action :create
            end
        end

        user_shell = can_login ? '/bin/bash' : '/usr/sbin/nologin'
        chef.user user_name do
            home user_home
            gid group_name
            shell user_shell
            system is_system
        end

        chef.bash "chown #{user_name} #{user_home}" do
            user 'root'
            code <<-EOH
chown #{user_name} #{user_home}
            EOH
        end
    end

    def self.delete_user(chef, user_name)
        chef.bash "delete_user: userdel #{user_name}" do
            user 'root'
            code <<-EOH
userdel #{user_name}
EOH
        end
    end

    def self.init_user(chef, app)

        can_login = false

    

        app[:run_as] ||= 'simple-test-app'
        app[:run_as_home] ||= "/home/#{app[:run_as]}"

        base = Chef::Recipe::Base
        unless base.user_exists app[:run_as]
          self.user chef, app, app[:run_as], app[:run_as_home], nil, can_login, false
        end

        unless app[:doc_root]

    
            app[:doc_root] = "#{app[:run_as_home]}/simple-test-app"
    

        end
    end

    def self.dir (chef, dir, app)
        dir = subst(dir, app)
        chef.directory dir do
            owner app[:run_as]
            group app[:run_as]
            mode '0755'
            action :create
        end
        permission(chef, dir, app, app[:run_as], app[:run_as], "u+rx")
    end

    def self.template_file(chef, template_src, template_dest, app)
        template_src = File.basename(template_dest) if template_src == '_'
        template_dest = subst(template_dest, app)

        chef.template template_dest do
            source "#{template_src}.erb"
            owner app[:run_as]
            group app[:run_as]
            mode '0700'
            variables ({ :app => app })
            action :create
        end
    end

    def self.symlink(chef, symlink_target, symlink_link, app, force = false)

        symlink_link = subst(symlink_link, app)

        target_parts = symlink_target.split
        if target_parts.first == 'which'
            # it's a command and they want us to find the path to it
            command = target_parts.last
            symlink_target = %x(which #{command}).strip
            raise "symlink: Command not found: #{command}" if symlink_target.nil? || symlink_target.empty?
        else
            # otherwise it's a regular path, perform subst on it
            symlink_target = subst(symlink_target, app)
        end

        force_command = force ? "rm #{symlink_link}" : ""
        chef.bash "ln -s #{symlink_target} #{symlink_link}" do
            user 'root'
            code <<-EOH
#{force_command}
ln -s #{symlink_target} #{symlink_link}
            EOH
            not_if { File.exists?(symlink_link) && !force }
        end
    end

    def self.permission(chef, path, app, chown, chgrp, perms, recursive = false)
        target = app.nil? ? path : subst(path, app)
        chown_target = chown.nil? ? nil : ( chown.include?('.') ? chown : (chgrp.nil? ? chown : "#{chown}.#{chgrp}") )
        recursive_flag = recursive ? '-R' : ''
        if chown_target.nil?
            unless chgrp.nil?
                chgrp = subst_string(chgrp, app)
                chef.bash "apply group=#{chgrp} to #{target}, recursive=#{recursive}" do
                    user 'root'
                    code <<-EOH
if [ ! -e "#{target}" ] ; then
  # but only if the target does not contain an asterisk...
  if echo x"#{target}" | grep '*' > /dev/null ; then
    echo "permission: target #{target} contains asterisk, not touching"
    chgrp #{recursive_flag} #{chgrp} #{target}
  else
    touch "#{target}"
    chgrp #{recursive_flag} #{chgrp} "#{target}"
  fi
else
  chgrp #{recursive_flag} #{chgrp} "#{target}"
fi
                    EOH
                end
            end
        else
            chown_target = app.nil? ? chown_target : subst_string(chown_target, app)
            chef.bash "apply ownership=#{chown_target} to #{target}, recursive=#{recursive}" do
                user 'root'
                code <<-EOH
if [ ! -e "#{target}" ] ; then
  # but only if the target does not contain an asterisk...
  if echo x"#{target}" | grep '*' > /dev/null ; then
    echo "permission: target #{target} contains asterisk, not touching"
    chown #{recursive_flag} #{chown_target} #{target}
  else
    touch "#{target}"
    chown #{recursive_flag} #{chown_target} "#{target}"
  fi
else
  chown #{recursive_flag} #{chown_target} "#{target}"
fi
                EOH
            end
        end

        unless perms.nil?
            chef.bash "apply perms=#{perms} to #{target}, recursive=#{recursive}" do
                user 'root'
                code <<-EOH
if [ ! -e "#{target}" ] ; then
  # but only if the target does not contain an asterisk...
  if echo x"#{target}" | grep '*' > /dev/null ; then
    echo "permission: target #{target} contains asterisk, not touching"
    chmod #{recursive_flag} #{perms} #{target}
  else
    touch "#{target}"
    chmod #{recursive_flag} #{perms} "#{target}"
  fi
else
  chmod #{recursive_flag} #{perms} "#{target}"
fi
                EOH
            end
        end
    end

    def self.move(chef, to, from, app)
        to = subst(to, app)
        from = subst(from, app)
        check = to
        check = check + "/#{File.basename from}" if File.directory? to

        chef.bash "mv #{from} #{to}" do
            user 'root'
            code <<-EOH
# check is #{check}
mv #{from} #{to}
            EOH
            only_if { %x(ls -1 #{check}).to_i == 0 }
        end
    end

    def self.copy(chef, to, from, app)
        to = subst(to, app)
        from = subst(from, app)
        chown = to.start_with?(app[:run_as_home]) || (!app[:doc_root].nil? && to.start_with?(app[:doc_root]))
        if chown
            chef.bash "rsync -avc #{from} #{to} ; #{chown} (app[:run_as_home] was #{app[:run_as_home]} and app[:doc_root] was #{app[:doc_root]}" do
                user 'root'
                code <<-EOH
files=$(rsync -avc #{from} #{to} | egrep -v "^sending incremental" | egrep -v "^sent .+ bytes" | egrep -v "^total size is ")
if [ $(echo "${files}" | tr -d ' ' | wc -c) -gt 0 ] ; then
    for file in ${files} ; do
      if [ -d "${file}" ] ; then
        chown -R #{app[:run_as]} #{to}/${file}
      elif [ -f "#{to}" ] ; then
        chown #{app[:run_as]} #{to}
      else
        chown #{app[:run_as]} #{to}/${file}
      fi
    done
fi
                EOH
            end
        else
            chef.bash "rsync -avc #{from} #{to}" do
                user 'root'
                code <<-EOH
rsync -avc #{from} #{to}
EOH
            end
        end
    end

    def self.append(chef, data, target, app)
        target = subst(target, app)
        chef.bash "appending to #{target} for app #{app[:name]}: #{data}" do
            user 'root'
            code <<-EOH
cat >> #{target} <<EOF
    #{data.gsub('$', '\\\\$')}
EOF
            EOH
            not_if { File.readlines("#{target}").grep(/Regexp.escape(data)/).size > 0 }
        end
    end

    def self.unappend(chef, data, target, app)
        base = Chef::Recipe::Base
        target = subst(target, app)
        base.remove_from_file(chef, target, data.gsub('$', '\\\\$'))
    end

    def self.exec (chef, app, exec, exec_user, dir, stdin = nil, unless_file = nil, env = nil)

        exec = subst_string(exec, app)
        exec_user ||= 'root'
        exec_user = subst_string(exec_user, app)
        dir = (dir.to_s == '') ? app[:run_as_home] : subst(dir, app)
        stdin = subst(stdin, app)
        unless_file = subst(unless_file, app)

        cmd = (stdin.to_s == '') ? exec : "echo '#{self.subst_string(stdin, app)}' | #{exec}"
        if cmd.start_with? '@bash'
          cmd = "#{cmd.sub('@bash', 'bash -c "')} #{cmd.gsub('"', '\"')} \""
        end

        if env
            new_env = {}
            env.each { |k, v| new_env[k] = subst_string(v, app) }
            env = new_env
        end

        chef.bash "exec: #{exec.split(/\s/)[0]} in #{dir} at #{Time.now}" do
            user 'root'
            cwd dir
            environment env if env
            code <<-EOH
if [ "#{exec_user}" = 'root' ] ; then
    #{cmd}
else
    sudo -u #{exec_user} -H #{cmd}
fi
            EOH
            only_if { unless_file.to_s == '' || !File.exists?(unless_file) }
        end

    end

    def self.logrotate (chef, app, path)
        base = Chef::Recipe::Base
        base.logrotate chef, subst(path, app)
    end

    def self.parse_jrun (app, command)
        command_parts = command.split(':')

        java_class = command_parts[1]
        java_yml = command_parts[2]
        java_yml = subst(java_yml, app) unless java_yml.nil?
        run_as = command_parts[3]
        run_as = subst_string(run_as, app) unless run_as.nil?
        run_as ||= app[:run_as]

        { :run_as => run_as, :java_class => java_class, :java_yml => java_yml }
    end

    def self.parse_wrap (app, command)
        command_parts = command.split(':')

        start_script = command_parts[1]
        stop_script = ''
        if start_script.include? ';'
            script_parts = start_script.split(';')
            start_script = subst(script_parts[0], app)
            stop_script = subst(script_parts[1], app)
        else
            start_script = subst(start_script, app)
        end

        pattern = subst_string(command_parts[2], app)
        pattern ||= start_script

        run_as = command_parts[3]
        run_as = subst_string(run_as, app) unless run_as.nil?
        run_as ||= app[:run_as]

        { :run_as => run_as, :start_script => start_script, stop_script => stop_script, :pattern => pattern }
    end

    def self.parse_sysinit (app, command)
        command_parts = command.split(':')
        command = subst(command_parts[0], app)
        pattern = subst_string(command_parts[1], app)
        pattern ||= command
        run_as = command_parts[3]
        run_as = subst_string(run_as, app) unless run_as.nil?
        run_as ||= app[:run_as]

        { :run_as => run_as, :command => command, :pattern => pattern }
    end

    def self.declare_sysinit (chef, app, command)
        if command.start_with? 'jrun'
            sysinit = parse_jrun app, command
            java = Chef::Recipe::Java
            app_config = java.declare_service subst('@name', app), sysinit[:java_class], sysinit[:java_yml]
            app[:services] << app_config

        elsif command.start_with? 'wrap'
            sysinit = parse_wrap app, command
            svc = generate_service_name app, sysinit[:start_script]
            app[:services] << { :service_name => svc, :proc_pattern => sysinit[:pattern] }

        else
            sysinit = parse_sysinit app, command
            svc = generate_service_name app, command

            init_svc = "/etc/init.d/#{svc}"
            app[:services] << { :service_name => svc, :proc_pattern => sysinit[:pattern] }
        end
        app[:service_names][command] = svc
    end

    def self.generate_service_name(app, command)
        # If this is the first service being defined, use the service name
        # Otherwise qualify with the script name
        if app[:services].empty?
            return app[:default_service_name]
        end

        base_svc_name = "#{app[:default_service_name]}_#{File.basename(command, File.extname(command))}"
        i = 0
        while i < 100
            candidate_svc_name = (i == 0) ? base_svc_name : "#{base_svc_name}_#{i}"
            ok = true
            app[:services].each do |service|
                if service[:service_name] == candidate_svc_name
                    # service name already exists, choose a next one
                    ok = false ; break
                end
            end
            if ok
                return candidate_svc_name
            end
            i += 1
        end
        raise "Error generating service name"
    end

    def self.create_sysinit (chef, app, command)
        svc = app[:service_names][command]
        if command.start_with? 'jrun'
            sysinit = parse_jrun app, command
            java = Chef::Recipe::Java
            java.create_service chef, subst('@name', app), sysinit[:run_as], sysinit[:java_class], sysinit[:java_yml]

        elsif command.start_with? 'wrap'
            sysinit = parse_wrap app, command
            init_svc = "/etc/init.d/#{svc}"

            unless File.exists? init_svc
                chef.template init_svc do
                    source "init_wrapper.sh.erb"
                    owner 'root'
                    group 'root'
                    mode '0755'
                    variables({
                        :start_script => sysinit[:start_script],
                        :stop_script => sysinit[:stop_script],
                        :app => app,
                        :service_name => svc,
                        :pattern => sysinit[:pattern],
                        :run_as => sysinit[:run_as]
                    })
                    action :create
                end

                chef.service svc do
                    pattern sysinit[:pattern]
                    supports [ :start => true, :stop => true ]
                    action [ :enable, :start ]
                end
            end

        else
            sysinit = parse_sysinit app, command
            init_svc = "/etc/init.d/#{svc}"

            unless File.exists? init_svc
                chef.template init_svc do
                    source 'init.sh.erb'
                    owner 'root'
                    group 'root'
                    mode '0755'
                    variables({
                        :command => sysinit[:command],
                        :pattern => sysinit[:pattern],
                        :run_as => sysinit[:run_as],
                        :service_name => svc,
                        :app => app
                    })
                    action :create
                end

                chef.service svc do
                    pattern sysinit[:command]
                    supports [ :start => true, :stop => true ]
                    action [ :enable, :start ]
                end
            end
        end
    end

    def self.declare_service (chef, app, name, pattern)
        pattern = name if pattern.to_s.empty?
        pattern = subst_string(pattern, app)
        # %x(echo "using pattern=#{pattern} for svc=#{name}" > /tmp/svc_#{name}.pattern)
        svc = name;
        app[:services] << { :service_name => svc, :proc_pattern => pattern }
        app[:service_names]["#{name}_#{pattern}".to_sym] = svc
    end

    def self.create_service (chef, app, name, pattern, provider = nil)
        pattern = name if pattern.to_s.empty?
        pattern = subst_string(pattern, app)
        chef.service app[:service_names]["#{name}_#{pattern}".to_sym] do
            pattern pattern
            provider provider
            supports :start => true, :stop => true, :restart => true
            action [ :enable, :start ]
        end
    end

    def self.stop_service (chef, app, service)
        chef.bash "stopping #{service[:service_name]} at #{Time.now}" do
            user 'root'
            code <<-EOH
service #{service[:service_name]} stop
if [ $? -ne 0 ] ; then
    sleep 2s
    num_procs=$(ps auxwwwww | egrep -- '#{service[:proc_pattern]}' | grep -v egrep | wc -l | tr -d ' ')
    if [ $num_procs -gt 0 ] ; then
        ps auxwwwww | egrep -- "#{service[:proc_pattern]}" | grep -v egrep | awk '{print $2}' | xargs kill
        sleep 5s
        num_procs=$(ps auxwwwww | egrep -- '#{service[:proc_pattern]}' | grep -v egrep | wc -l | tr -d ' ')
        if [ $num_procs -gt 0 ] ; then
            ps auxwwwww | egrep -- "#{service[:proc_pattern]}" | grep -v egrep | awk '{print $2}' | xargs kill -9
        fi
    fi
fi
EOH
        end
    end

    def self.restart_if_not_running (chef, app, service)
        chef.bash "validating #{service[:service_name]} is running (pattern=#{service[:proc_pattern]}) at #{Time.now}" do
            user 'root'
            code <<-EOH
num_procs=$(ps auxwwwww | egrep -- '#{service[:proc_pattern]}' | grep -v egrep | wc -l | tr -d ' ')
if [ $num_procs -gt 0 ] ; then
  exit 0
else
  service #{service[:service_name]} restart
  start=$(date +%s)
  while [ $(expr $(date +%s) - ${start}) -le 30 ] ; do
    num_procs=$(ps auxwwwww | egrep -- '#{service[:proc_pattern]}' | grep -v egrep | wc -l | tr -d ' ')
    if [ $num_procs -gt 0 ] ; then exit 0 ; fi
    sleep 2s
  done
fi
echo "service did not start: #{service[:service_name]}"
exit 1
EOH
        end
    end

    def self.validate_service (chef, app, service)
        chef.bash "validating #{service[:service_name]} is running (pattern=#{service[:proc_pattern]})" do
            user 'root'
            code <<-EOH
num_procs=$(ps auxwwwww | egrep -- '#{service[:proc_pattern]}' | grep -v egrep | wc -l | tr -d ' ')
if [ $num_procs -gt 0 ] ; then exit 0 ; else exit 1 ; fi
EOH
        end
    end

    def self.validate_web (chef, app, timeout = 1800, service_url = nil)
        service_url ||= app[:service_url]
        raise "No service URL found for app: #{app[:name]}" unless service_url

        service_map = []
        app[:services].each do |service|
            service_map << "#{service[:service_name]}|#{service[:proc_pattern]}"
        end

        chef.bash "validating #{app[:name]} is running: #{service_map} and listening on #{service_url}" do
            user 'root'
code <<-EOH

if [ ! -z '#{service_map.join("' '")}' ] ; then
  for service in '#{service_map.join("' '")}' ; do
    service_name="$(echo -n ${service} | awk -F '|' '{print $1}')"
    proc_pattern="$(echo -n ${service} | awk -F '|' '{print $2}')"
    num_procs=$(ps auxwwwww | egrep -- "${proc_pattern}" | grep -v egrep | wc -l | tr -d ' ')
    if [ ${num_procs} -eq 0 ] ; then
      echo "Restarting service that does not appear to be running: ${service_name} (pattern ${proc_pattern})" >> /tmp/validate_restart.log
      service ${service_name} restart
    fi
  done
fi

start=$(date +%s)
while [ $(expr $(date +%s) - ${start}) -lt #{timeout} ] ; do
  http_status="$(curl -sL -w "%{http_code}" --max-time 10 "#{service_url}" -o /dev/null)"
  rval=$?

  http_status_type=$(expr ${http_status} / 100)
  if [[ ${rval} -eq 0 && ( ${http_status_type} == 2 || ${http_status_type} == 3 ) ]] ; then

    echo "#{app[:name]} is running"
    exit 0
  else
    echo "Still waiting for #{app[:name]} to be running..."
    sleep 5s
  fi
done

echo "#{app[:name]} is not running"
exit 1

EOH
        end
    end

    def self.user_management (chef, app)
        

        chef.directory '/etc/rooty_handlers' do
            owner 'root'
            group 'root'
            mode '0700'
            action :create
        end

        chef.template "/etc/rooty_handlers/#{app[:name]}_user_mgmt.yml" do
            source 'rooty_handler.yml.erb'
            owner 'root'
            group 'root'
            mode '0400'
            variables({ :app => app })
            action :create
        end
    end

    def self.get_user_management_files (chef, app)
        files = []
        
        files << "/etc/rooty_handlers/#{app[:name]}_user_mgmt.yml"
        files
    end

    def self.cloudos_group (chef, app, name, description, quota, mirror, members)

        description = "--description '#{subst_string(description, app)}'" unless description.to_s.empty?
        quota       = "--quota       '#{subst_string(quota, app)}'"       unless quota.to_s.empty?
        mirror      = "--mirror      '#{subst_string(mirror, app)}'"      unless mirror.to_s.empty?
        members     = "--members     '#{subst_string(members, app)}'"     unless members.to_s.empty?

        chef.bash "create cloudos_group: #{name} with mirror=#{mirror} and members=#{members}" do
            user 'root'
            cwd '/tmp'
            code <<-EOH
cos sudo --command group --name #{name} --operation create #{description} #{quota} #{mirror} #{members}
            EOH
        end
    end

    def self.remove_cloudos_group (chef, app, name)
        chef.bash "create cloudos_group: #{name} with mirror=#{mirror} and members=#{members}" do
            user 'root'
            cwd '/tmp'
            code <<-EOH
cos sudo --command group --name #{name} --operation delete
EOH
        end
    end

    def self.generate_password_and_notify(chef, app, login, path, databag_file)
        base = Chef::Recipe::Base

        # Determine who should receive it
        if File.exist?("#{base.chef_databags('base')}/admin.json")
            admin = chef.data_bag_item('base', 'admin')
            admin_name = admin['name']
            admin_email = admin['email']
        else
            admin_name = 'cloudos administrator'
            admin_email = "postmaster@#{app[:hostname]}"
        end

        json_editor = "#{base.chef_files('base')}/json-editor"
        raise "No json-editor found: #{json_editor}" unless File.exist? json_editor

        gen_output = %x(#{subst('@files/autogen_pass.sh', app)} #{json_editor} #{app[:name]} #{login} #{path} #{databag_file} "#{admin_name}" #{admin_email} 8 2>&1)
        raise "Error generating password: #{gen_output}" unless $? == 0
    end

    def self.create_dns (chef, app, type, fqdn, ip, options = nil, ttl = nil)

        base = Chef::Recipe::Base

        ttl ||= 14400
        options_arg = options.to_s.empty? ? '' : "--options=\"#{options}\""

        chef.bash "create_dns: type=#{type} fqdn=#{fqdn} ip=#{ip} options=#{options} ttl=#{ttl}" do
            user 'root'
            code <<-EOH
cos cos-dns --operation add --record #{type.downcase} --fqdn #{fqdn} --value #{ip} --ttl #{ttl} #{options_arg}
EOH
        end
    end
end
