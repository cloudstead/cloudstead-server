#
# Cookbook Name:: simple-test-app
# Library:: apache_lib
#
# Copyright 2015 Cloudstead, Inc.
#

class Chef::Recipe::Simple_test_app

    def self.get_config (app)
        base = Chef::Recipe::Base
        config = {
            :mode => :proxy_service,
            :mount => app[:mount],
            :local_mount => app[:local_mount],
            :doc_root => app[:doc_root],

            

            

            

            

            

            
            :cert_name => nil, # use default (wildcard) SSL cert
            

            

            :server_name => nil
        }
        config[:vhost] = File.exist? subst('@templates/apache_vhost.conf.erb', app)

        if config[:cert_name]
            # The cert will tell us what our hostname should be
            # todo: implement whitelist of authorized domains, do not allow certs for others
            common_name = base.local_pem_cn('simple-test-app', config[:cert_name])
            config[:server_name] = common_name unless common_name.nil? || common_name.start_with?('*')
        end
        config
    end

    def self.apache_service_url (app)
        apache_lib = Chef::Recipe::Apache
        config = get_config(app)

    
        # has mount mode
        mount = 'bogus'
        mount = "/#{mount}" unless mount.start_with? '/'
        "https://#{app[:hostname]}#{mount}"
    

    end

    def self.apache (chef, app)
        base = Chef::Recipe::Base
        apache_lib = Chef::Recipe::Apache

        

        config = get_config(app)
        apache_java_webapp chef, app, config
    end

    def self.apache_uninstall (chef, app)
        apache_lib = Chef::Recipe::Apache
        apache_lib.uninstall_app chef, app, get_config(app)
        apache_reload chef, "uninstalled #{app[:name]}"
    end

    def self.apache_reload (chef, reason = nil)
        Chef::Recipe::Apache.reload(chef, reason)
    end

end