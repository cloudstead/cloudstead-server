#
# Cookbook Name:: simple-test-app
# Library:: apache_java_webapp_lib
#
# Copyright 2015 Cloudstead, Inc.
#

class Chef::Recipe::Simple_test_app

    def self.apache_java_webapp (chef, app, config)

        base = Chef::Recipe::Base
        apache = Chef::Recipe::Apache
        apache.enable_module(chef, 'proxy')
        apache.enable_module(chef, 'headers')

        config[:mode] ||= :proxy

        ports_bag = base.ports_databag chef, 'simple-test-app'
        app[:port] = config[:port] = ports_bag['primary']
        app[:admin_port] = config[:admin_port] = ports_bag['admin']

        apache.define_app(chef, 'simple-test-app', config)
    end

end