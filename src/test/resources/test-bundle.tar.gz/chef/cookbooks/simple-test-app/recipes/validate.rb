#
# Cookbook Name:: simple-test-app
# Recipe:: validate
#
# Copyright 2015 Cloudstead, Inc.
#
#


include_recipe 'apache::default'


base_lib = Chef::Recipe::Base
app_lib = Chef::Recipe::Simple_test_app
app = app_lib.define_app self

validate_services = false






if validate_services
    app[:services].each do |service|
        app_lib.restart_if_not_running self, app, service
        app_lib.validate_service self, app, service
    end
end


    
service_url = app[:service_url]
    
app_lib.validate_web self, app, 60, service_url



