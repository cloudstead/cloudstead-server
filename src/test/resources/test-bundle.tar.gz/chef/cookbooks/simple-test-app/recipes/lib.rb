#
# Cookbook Name:: simple-test-app v0.1.0
# Recipe:: lib
#
# Copyright 2015 Cloudstead, Inc.
#
# Exists only to load the libraries associated with the cookbook.
# Otherwise a no-op.
#

puts "simple-test-app::lib -- simple-test-app v0.1.0 library loaded"