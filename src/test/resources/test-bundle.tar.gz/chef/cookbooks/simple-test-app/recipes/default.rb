#
# Cookbook Name:: simple-test-app
# Recipe:: default
#
# Copyright 2015 Cloudstead, Inc.
#




include_recipe 'apache::default'




require 'securerandom'



base = Chef::Recipe::Base
app_lib = Chef::Recipe::Simple_test_app



# Install any certs provided
base.local_certs('simple-test-app').each do |cert_name|
  base.install_ssl_cert self, 'simple-test-app', cert_name
  Chef::Recipe::Java.install_cert(self, cert_name, base.pem_path(cert_name)) if defined? Chef::Recipe::Java.install_cert
end

app = app_lib.define_app self



















app_lib.init_java_webapp self, app if defined? app_lib.init_java_webapp








app_lib.apache self, app









  







  






if app[:doc_root]
  # ensure doc root is owned by / readable by apache group
  app_lib.permission(self, '@doc_root', app, nil, app[:run_as], '-R u+rx')

  # ensure doc root base world readable/listable (but not recursively, there may be private folders within)
  app_lib.permission(self, '@doc_root', app, nil, nil, 'a+rx')
end










app_lib.permission(self, '/var/www', app, 'root.root', nil, '755')
app_lib.apache_reload self


# Ensure services are running
app[:services].each do |service|
  app_lib.restart_if_not_running self, app, service
end


