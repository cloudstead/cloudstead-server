#
# Cookbook Name:: simple-test-app v0.1.0
# Recipe:: backup
#
# Copyright 2015 Cloudstead, Inc.
#

# creates a tarball containing simple-test-app backup files
# structure of the tarball:
# tmp/              contains the database dump and other ancillary files (if any)
# bin/              contains the simple-test-app binary files

base = Chef::Recipe::Base
app_lib = Chef::Recipe::Simple_test_app

app = app_lib.define_app self
app_lib.init self, app

timestamp = app[:backup_timestamp] = Time.new.strftime("%Y-%m-%d-%H%M%S")
backup_dir = app[:backup_dir] = "/var/cloudos/backup/simple-test-app"

tarball = "simple-test-app-#{timestamp}.tar"

init_bag = data_bag_item('cloudos', 'init')
run_as = init_bag['run_as']

directory backup_dir do
    owner "root"
    group "root"
    mode 0644
    recursive true
    action :create
end


# Stop all services
app[:services].each do |service|
    app_lib.stop_service self, app, service
end




directory "#{backup_dir}/tmp" do
    owner "root"
    group "root"
    mode 0644
    recursive true
    action :create
end





bash "back up simple-test-app data & files (with doc_root=#{app[:doc_root]})" do
    user "root"
    cwd backup_dir
    code <<-EOF
TIMESTAMP="#{timestamp}"
BACKUP_DIR=#{backup_dir}
TARBALL="#{tarball}"
RUNAS="#{run_as}"
#KEY="/home/${RUNAS}/.backup-key"
KEY="/etc/.cloudos"

echo "creating backup tarball at ${BACKUP_DIR}/${TARBALL}"


echo "adding doc_root to backup tarball"
tar rfp $BACKUP_DIR/$TARBALL #{app[:doc_root]}


if [ -d tmp ] ; then
  tar rfp $BACKUP_DIR/$TARBALL tmp
fi

bzip2 $BACKUP_DIR/$TARBALL

openssl enc -e -aes256 -pass file:$KEY -in $BACKUP_DIR/$TARBALL.bz2 -out $BACKUP_DIR/$TARBALL.enc

if [ -f $BACKUP_DIR/$TARBALL.bz2 ] ; then
  echo "backup tarball created"

  if [ -f $BACKUP_DIR/$TARBALL.enc ] ; then
    echo "backup tarball encrypted"
    rm $BACKUP_DIR/$TARBALL.bz2
  fi
else
  # should we clean up the db dump in this case?
  echo "couldn't create tarball"
  exit 1
fi
EOF
end



# Ensure services are running
app[:services].each do |service|
  app_lib.restart_if_not_running self, app, service
end
