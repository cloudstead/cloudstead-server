#
# Cookbook Name:: simple-test-app
# Recipe:: uninstall
#
# Copyright 2015 Cloudstead, Inc.
#
#




include_recipe 'apache::default'


app_lib = Chef::Recipe::Simple_test_app
app = app_lib.define_app self

# todo: remove packages
# requires that we scan all other active manifests (and possibly recipes)
# for other active apps that may still depend on the package

# Remove/disable web configs

app_lib.apache_uninstall self, app

# todo: remove/disable web modules and other web-configs
# requires that we scan all other active manifests/recipes for extant dependencies


# Track files to delete here
to_delete = []

# Stop all services
app[:services].each do |service|
    app_lib.stop_service self, app, service
    to_delete << "/etc/init.d/#{service[:service_name]}"
done


# Remove user home and doc_root if they are set
to_delete << app[:run_as_home] unless app[:run_as_home].nil?
to_delete << app[:doc_root] unless app[:doc_root].nil?





















    




# Delete files
to_delete = to_delete.flatten.join ' '
unless to_delete.empty?
    bash "deleting simple-test-app files: #{to_delete}" do
        user 'root'
        code <<-EOF

# Could be a lot of files, use xargs + heredoc to avoid any limits on command line length
xargs rm -rf <<-DEL
#{to_delete}
DEL

EOF
    end
end


# Reload web server
app_lib.apache_reload self

