#
# Cookbook Name:: simple-test-app v0.1.0
# Recipe:: restore
#
# Copyright 2015 Cloudstead, Inc.
#

# NB: this recipe assumes that the backup tarball has already been downloaded and
# unzipped into restore_dir

base = Chef::Recipe::Base
app_lib = Chef::Recipe::Simple_test_app

app = app_lib.define_app self
app_lib.init self, app

timestamps_bag = data_bag_item('restore', 'timestamps')
timestamp = app[:backup_timestamp] = timestamps_bag['simple-test-app']
backup_dir = app[:backup_dir] = "/var/cloudos/backup/simple-test-app"

init_bag = data_bag_item('cloudos', 'init')
run_as = init_bag['run_as']

# before we do anything else, check the currently running app version to make sure it corresponds
# to the version we're backed up for

app_metadata = JSON.parse(File.read("/home/#{run_as}/app-repository/simple-test-app/metadata.json"))
active_version = app_metadata['active_version']
if active_version != '0.1.0'
    Chef::Application.fatal!('Restore failed. The currently active version of simple-test-app is #{active_version};
the restore recipe supports version 0.1.0. It may be possible to reinstall simple-test-app v0.1.0 from
a cloudos backup tarball.')
end


# Stop all services
app[:services].each do |service|
  app_lib.stop_service self, app, service
end




bash "restore simple-test-app" do
  user "root"
  cwd backup_dir
  code <<-EOF
echo "restoring files from backup at #{backup_dir}"

for rootdir in etc var ; do
  if [ -d ./${rootdir} ] ; then
    chown -R root.root ./${rootdir}
  fi
done
if [ -d ./home ] ; then
  chown -R #{app[:run_as]} ./${rootdir}
fi

rsync -avzc --exclude="*.enc" ./* /

# ensure that backup_dir, /tmp /etc /var and /home maintain proper ownership and permissions
chmod 1777 /tmp && chown root.root /tmp
for rootdir in /etc /var /home ; do
  chmod 755 ${rootdir} && chown root.root ${rootdir}
done
chown -R #{base.chef_user} #{backup_dir}
EOF

end


# Ensure app filesystem ownership and permissions are set correctly
if app[:run_as] != 'www-data' && app[:run_as_home] != nil
  app_lib.permission self, app[:run_as_home], app, app[:run_as], 'root', '770', true
end
    






# Ensure services are running
app[:services].each do |service|
  app_lib.restart_if_not_running self, app, service
end
