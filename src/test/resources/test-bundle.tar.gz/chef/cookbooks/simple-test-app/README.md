simple-test-app Cookbook
=================
Installs and configures simple-test-app on a cloudos instance.




This app will create a web-accessible service in Apache



