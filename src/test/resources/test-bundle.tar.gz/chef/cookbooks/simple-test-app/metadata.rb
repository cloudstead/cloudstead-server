name             'simple-test-app'
maintainer       'Jonathan Cobb'
maintainer_email 'jonathan@cloudstead.io'
license          'https://www.gnu.org/licenses/agpl-3.0.txt'
description      'simple-test-app'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '0.1.0'




depends 'apache'



